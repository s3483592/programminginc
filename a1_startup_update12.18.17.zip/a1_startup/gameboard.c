/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/

#include "gameboard.h"

/**
 * in this file you will need to define the functions for intialisation and 
 * manipulation of the game board array. Note: I have provided the function
 * prototype for initialisation but you may wish to add other functions to 
 * manipulate the game board. 
 **/

/**
 * you'll need to initialise the game board to all spaces. Have a look at the 
 * definition of enum token in "shared.h" as the gameboard is a 2-d array of 
 * those.
 **/
void gameboard_init(gameboard board)
{
    int row;
    int column;
    for (row = 0; row < MAXWIDTH; row++)
    {
        for(column = 0; column < MAXHEIGHT; column++)
        {
            board[row][column] = EMPTY;

        }
    }
}

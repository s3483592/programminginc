/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/

#include "gameio.h"
#include "game.h"

#define INT_MAX_STRING_LENGTH 1
#define MAXINTEGERLENGTH 10
/**
 * function that performs buffer clearing when you detect that too much input
 * has been entered. Have a look at the course examples to see how to use this
 * function correctly. Understanding of the operation of buffering is essential
 * to understanding input and output in C and there is a lot of misunderstanding
 * of this topic. If you struggle with this, please ensure that you ask lots of 
 * questions.
 **/
void read_rest_of_line(void)
{
        int ch;
        while (ch = getc(stdin), ch != '\n' && ch != EOF)
                ;
        clearerr(stdin);
}


/**
 * this function provides a printf like interface for you to use to print out
 * error messages from your program. You provide the format specifier as the
 * first argument followed by any other arguments. It does some minor formatting
 * such as prepending "Error: " to all your error messages which is required
 * for my tester of your program
 **/
int print_error(const char format[], ...)
{
        int numchars;
        va_list arg_list;
        numchars = fprintf(stderr, "Error: ");
        /* retrieve the argument list */
        va_start(arg_list, format);
        /* pass the argument list to vprintf */
        numchars += vfprintf(stderr, format, arg_list);
        /* stop processing the argument list */
        va_end(arg_list);
        return numchars;
}

/**
 * displays the game board for the game. The game board array itself it the
 * same size regardless of the official board_dimension but it only draws a
 * board sufficient to draw the game state's board.
 **/
void display_board(struct game* thegame)
{
    int t;
    int lineCount;
    lineCount = 1;
    if(thegame->board_dimension == 3)
    {
        printf ("   | 1 | 2 | 3 |");
        printf("\n----------------\n");

        for(t = 0; t < thegame->board_dimension; t++)
        {
            printf (" %i | %c  | %c  | %c  |", lineCount, thegame->board[t][0],
            thegame->board[t][1],thegame->board[t][2]);
            lineCount++;
            if(t!=2) printf("\n----------------\n");
        }
        printf("\n----------------\n");
        printf("\n");

    }
    else
    {
        printf ("   | 1 | 2 | 3 | 4 | 5 |");
        printf("\n------------------------\n");

        for(t = 0; t < thegame->board_dimension; t++)
        {
            printf (" %i | %c  | %c  | %c  | %c  | %c  |", lineCount, thegame->board[t][0],
            thegame->board[t][1],thegame->board[t][2],thegame->board[t][3],thegame->board[t][4]);
            lineCount++;
            if(t!=4) printf("\n------------------------\n");
        }
        printf("\n------------------------\n");
        printf("\n");

    }
    
    
    
    
    /**int row;
    int column;
    int lineCount;
    for (row = 0; row < thegame->board_dimension; row++)
    {
        for(column = 0; column < thegame->board_dimension; column++)
        {
            printf("%i", thegame->board[row][column]);
            if (column !=thegame->board_dimension-1)
            {
                printf(" | ");
            }
            
        }
        if(row !=thegame->board_dimension-1)
        {
            printf("\n-----------------");
        }
        printf("\n");
    }**/
}

/**
 * function to allow you to print out general informational messages
 **/
int print_message(const char format[], ...)
{
        /* print out a leading info tag */
        int numchars = printf("%s", "Info: ");
        /* extract the data passed from the ... and pass it into printf */
        va_list arg_list;
        va_start(arg_list, format);
        numchars += vprintf(format, arg_list);
        va_end(arg_list);
        /* return the number of chars printed consistent with the printf
         * interface */
        return numchars;
}
/** Steve Burrows and Paul Miller - getInteger-advance / getInteger-basic : June 2006, last modified by me**/
void getInteger(int* integer, const unsigned length, const char* prompt)
{
    int finished = FALSE;
    char output[INT_MAX_STRING_LENGTH + EXTRACHARS];
    int int_result = 0;
    char* endPtr;

    do
    {
        printf("%s", prompt);

        fgets(output, length + EXTRACHARS, stdin);

        if(output[strlen(output) -1] !='\n')
        {
            print_error("input was too long.\n");
            read_rest_of_line();
        }
        else
        {
            output[strlen(output) - 1] = '\0';

            int_result = (int) strtol(output, &endPtr, 0);

            if(*endPtr!=0)
            {
                print_error("input was not a number. \n");
            
            }
            else
            {
                finished = TRUE;
            }
        }
    }while(finished == FALSE);

    *integer = int_result;
}



void menuStart()
{
    printf("\n");
    printf("Welcome to tictactoe \n");
    printf("- - - - - - - - - - - - - - -  \n");
    printf("1) Play Game \n");
    printf("2) Exit \n");
}


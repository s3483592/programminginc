/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
#include "main.h"
#include "shared.h"

/**
 * entry point for the system to run your code. Please take the comments below 
 * as hints for the code you need to write in this function.
 **/
int main(void)
{    
        /* loop until the user decides to quit */
                /* display the menu */
                /* get the user's selection of option to run */
                /* execute the user's option and if that is to quit, set the 
                 * appropriate variable for exiting or exit directly */
        BOOLEAN exitMainMenu = FALSE;
        do
        {
                menuStart();
                switch (getMenuOption())
                {
                case 1 :
                        printf("Play Game \n");
                        play_game();
                        break;
                case 2 :
                        printf("Exit Menu \n");
                        exitMainMenu = TRUE;
                        break;
                default:
                        print_error("Invaild choice entered, try again\n");
                        break;
                }
        }while (!exitMainMenu);
        return EXIT_SUCCESS;
}


/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
/***************************************************************************\
*              Below are all the includes and definitions for this file     *
*                                                                           *
\***************************************************************************/

#ifndef SHARED_H
#define SHARED_H


/***************************************************************************\
*              Below are all the other things for this file to work         *
*                                                                           *
\***************************************************************************/
/**
 * this file is provided for any global types that need to be defined and
 * available from all places in the application. No other files should be
 * included in this file as that might creat some recursive includes
 **/

/**
 * the BOOLEAN type - defines TRUE and FALSE
 **/
typedef enum
{
        FALSE,
        TRUE
} BOOLEAN;

/**
 * the maximum length of a player name is 20 chars
 **/
#define NAMELEN 20

/**
 * the token values for the gameboard
 **/
enum token
{
        EMPTY,
        NOUGHT,
        CROSS
};

/**
 * defines a location on the game board as an X and Y pair. Being the offset
 * into the horizontal and vertical dimensions of the board
 **/
struct coordinate
{
        int x, y;
};

#endif


/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
/***************************************************************************\
*              Below are all the includes and definitions for this file     *
*                                                                           *
\***************************************************************************/
#include "player.h"
#include "game.h"


/***************************************************************************\
*              Below are all the other things for this file to work         *
*                                                                           *
\***************************************************************************/
/**
 * provides a mapping from tokens to chars for display
 **/
const char token_chars[NUMTOKENCHARS] = { ' ', 'O', 'X' };

/**
 * initialises a player based on user input and the game pointer passed into
 * the init_player function. We do this because there's no such thing as a
 * player outside of a game. If we did not do this we would have to pass thegame
 * into player every time we called a function in player.
 **/
void init_player(struct player* new_player, enum player_type type,
                 struct game* thegame)
{
    if(type == COMPUTER)
    {
        
        new_player->type = COMPUTER;
        strcpy(new_player->name, "Computer");
        printf("\nWhat is your name? My name is %s\n", new_player->name);
    }
    if(type == HUMAN)
    {
        
        char string[STR_LENGTH + 1];
        char prompt[PROMPT_LENGTH + 1];
        new_player->type = HUMAN;
        sprintf(prompt, "Enter a name : ");
        getString(string, STR_LENGTH, prompt);
        strcpy(new_player->name, string);
        
    }
    
}

/**
 * This function handles turns for both human and computer players. 
 *
 * In all cases, display the state of the board first.
 * 
 * If this is a human player, prompt for their move validate it and if it 
 * is valid, apply it. If it is not valid, reprompt until a valid ove is 
 * entered.
 *
 * If this is a computer player, generate random x and y values for a move. Test
 * if the move is a valid move, apply it, otherwise try again generating a new
 * random x and y pair.
 **/
void take_turn(struct player* curplayer)
{
}


/***************************************************************************\
*              Below are all the functions that can be used in this file    *
*                                                                           *
\***************************************************************************/
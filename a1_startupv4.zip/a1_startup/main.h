/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
/***************************************************************************\
*              Below are all the includes and definitions for this file     *
*                                                                           *
\***************************************************************************/
#include "game.h"
#include <stdlib.h>


/***************************************************************************\
*              Below are all the other things for this file to work         *
*                                                                           *
\***************************************************************************/
 int getMenuOption();

 int getMenuOption()
{
    int menuOption;
    char menuPrompt[LINELEN + 1];
    sprintf(menuPrompt, "Select an option: ");
    getInteger(&menuOption, MAIN_MENU_INPUT_LENGTH, menuPrompt);
    return menuOption;
}

/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
/***************************************************************************\
*              Below are all the includes and definitions for this file     *
*                                                                           *
\***************************************************************************/

#include "game.h"
#include "rules.h"

/***************************************************************************\
*              Below are all the functions in this file                     *
*                                                                           *
\***************************************************************************/

/**
 * this function swaps the pointers to the two players in the game. It is the
 * code responsible for changing the current player. Please note that many
 * of you will find it difficult to figure out what to do for this function.
 * This is considered a high distinction requirement and as such not something
 * that everyone is expected to be able to do. For this reason, this function
 * is worth 5 bonus marks.
 **/
void swap_players(struct player** first, struct player** second)
{
}

/**
 * This function is responsible for the initialisation of the game (and thus
 * the game struct. First initialise all structures to be empty (including
 * players and the board. Next, ask the player for the player's name and assign
 * the token values to the players and also initialise the computer player,
 **/
void init_game(struct game* thegame)
{
        int player1Type;
        int player2Type;
        int player1Token;
        int player2Token;
        thegame->quit = FALSE;
        thegame->board_dimension = 0;
        thegame->num_in_row = 0;
        gameboard_init(thegame->board);
        player_randomize(&player1Type, &player2Type);
        init_player(&thegame->players[0], player1Type, thegame);
        init_player(&thegame->players[1], player2Type, thegame);
        player_randomize(&player1Token, &player2Token);
        set_player_token(&thegame->players[0], player1Token);
        set_player_token(&thegame->players[1], player2Token); 
}

/**
 * the main function that manages the game loop. You'll need to call
 * initialisation functions. To initialise the game struct, which includes the
 * players and then it's just a matter of alternating turns until the end of
 * the game. At the end of the game, you'll need to print out details of the
 * final game state.
 **/
void play_game(void)
{
        struct game thegame;
        init_game(&thegame);
        set_board_dimension(&thegame);
        set_num_in_row(&thegame);
        player_print(&thegame.players[0]);
        player_print(&thegame.players[1]);
        display_board(&thegame);
}

/***********************************************************************
* CPT220 - Programming in C
* Study Period 4 2017 Assignment #1 
* Full Name        : Joshua Daniel Nicholson
* Student Number   : s3483592
* Start up code provided by Paul Miller
***********************************************************************/
/***************************************************************************\
*              Below are all the includes and definitions for this file     *
*                                                                           *
\***************************************************************************/
#include "gameio.h"
#include "game.h"
#include <time.h>
#define INT_MAX_STRING_LENGTH 1
#define MAXINTEGERLENGTH 10
#define STR_LENGTH 25


/***************************************************************************\
*              Below are all the other things for this file to work         *
*                                                                           *
\***************************************************************************/

/***************************************************************************\
* read_rest_of_line                                                         *                                                                         *
\***************************************************************************/
/**
 * function that performs buffer clearing when you detect that too much input
 * has been entered. Have a look at the course examples to see how to use this
 * function correctly. Understanding of the operation of buffering is essential
 * to understanding input and output in C and there is a lot of misunderstanding
 * of this topic. If you struggle with this, please ensure that you ask lots of 
 * questions.
 **/
void read_rest_of_line(void)
{
        int ch;
        while (ch = getc(stdin), ch != '\n' && ch != EOF)
                ;
        clearerr(stdin);
}
/***************************************************************************\
* print error                                                               *                                                                         *
\***************************************************************************/
/**
 * this function provides a printf like interface for you to use to print out
 * error messages from your program. You provide the format specifier as the
 * first argument followed by any other arguments. It does some minor formatting
 * such as prepending "Error: " to all your error messages which is required
 * for my tester of your program
 **/
int print_error(const char format[], ...)
{
        int numchars;
        va_list arg_list;
        numchars = fprintf(stderr, "Error: ");
        /* retrieve the argument list */
        va_start(arg_list, format);
        /* pass the argument list to vprintf */
        numchars += vfprintf(stderr, format, arg_list);
        /* stop processing the argument list */
        va_end(arg_list);
        return numchars;
}
/***************************************************************************\
* print message                                                             *                                                                         *
\***************************************************************************/
/**
 * function to allow you to print out general informational messages
 **/
int print_message(const char format[], ...)
{
        /* print out a leading info tag */
        int numchars = printf("%s", "Info: ");
        /* extract the data passed from the ... and pass it into printf */
        va_list arg_list;
        va_start(arg_list, format);
        numchars += vprintf(format, arg_list);
        va_end(arg_list);
        /* return the number of chars printed consistent with the printf
         * interface */
        return numchars;
}
/***************************************************************************\
* getInteger                                                                *                                                                         *
\***************************************************************************/
/** Steve Burrows and Paul Miller - getInteger-advance / getInteger-basic : June 2006, last modified by me**/
void getInteger(int* integer, const unsigned length, const char* prompt)
{
    int finished = FALSE;
    char output[INT_MAX_STRING_LENGTH + EXTRACHARS];
    int int_result = 0;
    char* endPtr;


    do
    {
        printf("%s", prompt);

        fgets(output, length + EXTRACHARS, stdin);

        /**if()**/
        if(output[strlen(output) -1] !='\n')
        {
            print_error("input was too long.\n");
            read_rest_of_line();
        }
        else
        {
            output[strlen(output) - 1] = '\0';

            int_result = (int) strtol(output, &endPtr, 0);

            if(*endPtr!=0)
            {
                print_error("input was not a number. \n");
            
            }
            else
            {
                finished = TRUE;
            }
        }
    }while(finished == FALSE);

    *integer = int_result;
}
/***************************************************************************\
* getString                                                                *                                                                         *
\***************************************************************************/
BOOLEAN getString(char* output_string, const unsigned length, const char* prompt)
{
    int finished = FALSE;
    char inputString[STR_LENGTH + EXTRACHARS];

    do
    {
        printf("%s", prompt);
        fgets(inputString, length + EXTRACHARS, stdin);
        if(inputString[strlen(inputString) -1] != '\n')
        {
            printf("input was too long.\n");
            read_rest_of_line();
        }
        else
        {
            finished = TRUE;
        }
    }while(finished == FALSE);

    inputString[strlen(inputString) -1] = '\0';
    strcpy(output_string, inputString);

    return TRUE;
}
/***************************************************************************\
* display_board                                                                *                                                                         *
\***************************************************************************/
/**
 * displays the game board for the game. The game board array itself it the
 * same size regardless of the official board_dimension but it only draws a
 * board sufficient to draw the game state's board.
 **/
void display_board(struct game* thegame)
{
    int t;
    int lineCount;
    lineCount = 1;
    if(thegame->board_dimension == 3)
    {
        printf ("   | 1 | 2 | 3 |");
        printf("\n----------------\n");

        for(t = 0; t < thegame->board_dimension; t++)
        {
            printf (" %i | %c | %c | %c |", lineCount, token_chars[thegame->board[t][0]],
            token_chars[thegame->board[t][1]],token_chars[thegame->board[t][2]]);
            lineCount++;
            if(t!=2) printf("\n----------------\n");
        }
        printf("\n----------------\n");
        printf("\n");

    }
    else
    {
        printf ("   | 1 | 2 | 3 | 4 | 5 |");
        printf("\n------------------------\n");

        for(t = 0; t < thegame->board_dimension; t++)
        {
            printf (" %i | %c | %c | %c | %c | %c |", lineCount, 
            token_chars[thegame->board[t][0]],token_chars[thegame->board[t][1]],
            token_chars[thegame->board[t][2]],token_chars[thegame->board[t][3]],
            token_chars[thegame->board[t][4]]);
            lineCount++;
            if(t!=4) printf("\n------------------------\n");
        }
        printf("\n------------------------\n");
        printf("\n");

    }
}
/***************************************************************************\
* menuStart                                                                *                                                                         *
\***************************************************************************/
void menuStart(void)
{
    printf("\n");
    printf("Welcome to tictactoe \n");
    printf("------------------------\n");
    printf("1) Play Game \n");
    printf("2) Exit \n");
}
/***************************************************************************\
* set_board_dimension                                                                *                                                                         *
\***************************************************************************/
void set_board_dimension(struct game* thegame)
{
    
    char boardDimensionPrompt[LINELEN + 1];
    printf("You can play tictactoe on a 3x3 board or a 5x5 board.\n");
    sprintf(boardDimensionPrompt, "Do you want to play on a board width of 3 or 5? ");
    getInteger(&thegame->board_dimension, BOARD_INPUT_LENGTH, boardDimensionPrompt);
    /**if (thegame->board_dimension == 3)
    {
        printf("I was here\n\n");
        thegame->num_in_row = 3;       
    }
    else
    {

    }
    return;**/
    
}
/***************************************************************************\
* set_num_in_row                                                                *                                                                         *
\***************************************************************************/
void set_num_in_row(struct game* thegame)
{
    if(thegame->board_dimension == 3)
    {
        thegame->num_in_row = 3;
        return;
    }
    else
    {
        char numInRowPrompt[LINELEN + 1];
        sprintf(numInRowPrompt, "How many pieces in a row are required for a win? 3, 4 or 5? ");
        getInteger(&thegame->num_in_row, BOARD_INPUT_LENGTH, numInRowPrompt);
    }
}

/***************************************************************************\
* player_randomize                                                               *                                                                         *
\***************************************************************************/
void player_randomize(int* player1, int* player2)
{
    int seed = time(NULL);
    int Player1_Num; 
    int Player2_Num; 
    srand(seed);

    do
    {
        Player1_Num = rand()%2;
        Player2_Num = rand()%2;
        
    }
    while(Player1_Num == Player2_Num);
    *player1 = Player1_Num;
    *player2 = Player2_Num;
    /**return 0;**/
    
}
/***************************************************************************\
* set_player_token                                                               *                                                                         *
\***************************************************************************/

void set_player_token(struct player* player, int playerToken)
{
    if(playerToken == 0)
    {
        player->token = NOUGHT;
        return;
    }
    else
    {
        player->token = CROSS;
    }
    
}
/***************************************************************************\
* helper: player_print                                                      *                                                                         *
\***************************************************************************/

void player_print(struct player* player)
{
    printf("The player's name is %s\n", player->name);
    printf("The player's type is %i\n", player->type);
    printf("The player's token is %c\n", token_chars[player->token]);
}

/***************************************************************************\
*              Below are all the functions that can be used in this file    *
*                                                                           *
\***************************************************************************/
